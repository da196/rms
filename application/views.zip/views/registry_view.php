<?php 

// START CALL ALL THE MODELS HERE...
$this->load->model('registry_causes_model');
$this->load->model('registry_events_model');
$this->load->model('registry_consequences_model');
// END CALL ALL THE MODELS HERE...

?>


<!-- START -->
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-9">
    <h2> Review & Assess Risk Register</h2>
        <ol class="breadcrumb">
            <li>
                 <a>Risk Register</a>
            </li>
            <li class="active">
                <a href="<?php echo base_url();?>registry/view"> <strong> Review & Assess  </strong></a>
                           
            </li>
         </ol>
    </div>
</div>


<div class="wrapper wrapper-content animated fadeIn">
<div class="row">
    <div class="col-lg-12">
        <div class="tabs-container">
            <ul class="nav nav-tabs" role="tablist">
                <li><a class="nav-link active" data-toggle="tab" href="#tab-1"> Strategic - Risk Category </a></li>
                <li><a class="nav-link" data-toggle="tab" href="#tab-2"> Operational - Risk Category </a></li>
                <li><a class="nav-link" data-toggle="tab" href="#tab-3"> Project - Risk Category </a></li>
            </ul>
            <div class="tab-content">
                <!-- All the Strategic Risk Category -->
                <div role="tabpanel" id="tab-1" class="tab-pane active">
                    <div class="panel-body">
                    <!-- START  BODY -->
                    <div class="row">
                        <div class="col-lg-12">                   
                                    <h4>List of Risk Register (Strategic Category) </h4>                                                       
                                        <div class="table-responsive">
                                            <table class="table table-striped table-bordered table-hover" id="dataTable_riskEmerge">
                                            <thead>
                                            <tr>
                                                <th>Activity</th>
                                                <th>Causes </th>
                                                <th>Events </th>                                                   
                                                <th>Consequences</th>                   
                                                <th>Trend</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php 
                                            if($list_strategic_registry->num_rows() > 0) {
                                                foreach($list_strategic_registry->result() as $row){
                                            ?>
                                                    <tr class="gradeX">
                                                    <td><?php echo  $row->activity; ?></td>
                                                    <!-- CAUSES -->
                                                    <td>
                                                        <ol>
                                                            <?php
                                                            $list_causes  = $this->registry_model->getRegistry_causes($row->id);
                                                            foreach($list_causes->result() as $cause){?>                                       
                                                                <li><?php echo  $cause->causes; ?></li>
                                                            <?php } ?>
                                                        </ol>
                                                    </td>

                                                    <!-- EVENTS -->
                                                    <td>
                                                        <ol>
                                                            <?php 
                                                            $list_events  = $this->registry_model->getRegistry_events($row->id);
                                                            foreach($list_events->result() as $event){?>                                       
                                                                <li><?php echo  $event->events; ?></li>
                                                            <?php } ?>
                                                        </ol>
                                                    </td>

                                                    <!-- CONSEQUENCES -->
                                                    <td>
                                                        <ol>
                                                            <?php 
                                                            $list_consequences  = $this->registry_model->getRegistry_consequences($row->id);
                                                            foreach($list_consequences->result() as $consequence){?>                                       
                                                                <li><?php echo  $consequence->consequences; ?></li>
                                                            <?php } ?>
                                                        </ol>
                                                    </td>


                                                    <?php 
                                                    if($row->trend_name == 'Upward - Amber')
                                                    {
                                                        $label = 'warning';
                                                        $font_label = 'arrow-up';
                                                    }elseif($row->trend_name == 'Downward - Amber')
                                                    {
                                                       $label = 'warning';
                                                       $font_label = 'arrow-down';  
                                                    }
                                                    elseif($row->trend_name == 'Constant - Red')
                                                    {
                                                       $label = 'danger';
                                                       $font_label = 'exchange';  
                                                    }
                                                    elseif($row->trend_name == 'Constant - Green')
                                                    {
                                                       $label = 'primary';
                                                       $font_label = 'exchange';  
                                                    }
                                                     elseif($row->trend_name == 'Constant - Amber')
                                                    {
                                                       $label = 'warning';
                                                       $font_label = 'exchange';  
                                                    }
                                                    elseif($row->trend_name == 'Downward - Red')  
                                                    {
                                                        $label = 'danger';
                                                        $font_label = 'arrow-down';
                                                    }
                                                    else
                                                    {
                                                        $label = 'primary';
                                                        $font_label = 'arrow-up';
                                                    }
                                                    ?>
                                                    <td> 
                                                        <i class="fa fa-<?php echo $font_label;?> fa-lg"></i>
                                                        <span class="label label-<?php echo $label;?>"><?php echo  $row->trend_name;?> </span>  
                                                    </td>
                                                   
                                                   <td>
                                                        <button class="btn-white btn btn-xs"><i class="fa fa-list"></i><a onClick="viewRegistryFunction(<?php echo $row->id; ?>)" data-toggle="modal" data-target="#viewRegistryModal"> Review </a></button>
                                                        </br> 

                                                        <?php
                                                        $rmu_only = array(4,7);
                                                        if(in_array($this->session->userdata('role'), $rmu_only)) { ?>
														<button class="btn-white btn btn-xs"><i class="fa fa-edit"></i> <a href="<?php echo base_url();?>registry/registry_edit/<?php echo $row->id;?>" > Assess </a></button>
                                                        <?php } ?>

                                                    </td>
                                                </tr>
                                                <?php  }
                                            }else{ ?>
                                                <tr class="gradeX">
                                                    <td colspan="5">Risk Register has no data to assess</td>
                                                </tr>                            
                                                <?php  } ?>                    
                                            </tbody>
                                            <tfoot>
                                            <tr>
                                                <th>Activity</th>
                                                <th>Causes </th>
                                                <th>Events </th>                                                   
                                                <th>Consequences</th>                   
                                                <th>Trend</th>
                                                <th>Action</th>
                                            </tr>
                                            </tfoot>
                                            </table>                                   
                                        </div>
                            </div>
                        </div>
                    <!-- END BODY -->
                    </div>
                </div>


                <!-- All the Operational Risk Category -->
                <div role="tabpanel" id="tab-2" class="tab-pane">
                    <div class="panel-body">
                    <!-- START  BODY -->
                    <div class="row">
                        <div class="col-lg-12">                   
                                    <h4>List of Risk Register (Operational Category) </h4>                                                       
                                        <div class="table-responsive">
                                            <table class="table table-striped table-bordered table-hover" id="dataTable2_riskEmerge">
                                            <thead>
                                            <tr>
                                                <th>Activity</th>
                                                <th>Causes </th>
                                                <th>Events </th>                                                   
                                                <th>Consequences</th>                   
                                                <th>Trend</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php 
                                            if($list_operational_registry->num_rows() > 0) {
                                                foreach($list_operational_registry->result() as $row){
                                            ?>
                                                    <tr class="gradeX">
                                                    <td><?php echo  $row->activity; ?></td>
                                                    <!-- CAUSES -->
                                                    <td>
                                                        <ol>
                                                            <?php
                                                            $list_causes  = $this->registry_model->getRegistry_causes($row->id);
                                                            foreach($list_causes->result() as $cause){?>                                       
                                                                <li><?php echo  $cause->causes; ?></li>
                                                            <?php } ?>
                                                        </ol>
                                                    </td>

                                                    <!-- EVENTS -->
                                                    <td>
                                                        <ol>
                                                            <?php 
                                                            $list_events  = $this->registry_model->getRegistry_events($row->id);
                                                            foreach($list_events->result() as $event){?>                                       
                                                                <li><?php echo  $event->events; ?></li>
                                                            <?php } ?>
                                                        </ol>
                                                    </td>

                                                    <!-- CONSEQUENCES -->
                                                    <td>
                                                        <ol>
                                                            <?php 
                                                            $list_consequences  = $this->registry_model->getRegistry_consequences($row->id);
                                                            foreach($list_consequences->result() as $consequence){?>                                       
                                                                <li><?php echo  $consequence->consequences; ?></li>
                                                            <?php } ?>
                                                        </ol>
                                                    </td>

                                                    <?php                                                

                                                    if($row->trend_name == 'Upward - Amber')
                                                    {
                                                        $label = 'warning';
                                                        $font_label = 'arrow-up';
                                                    }elseif($row->trend_name == 'Downward - Amber')
                                                    {
                                                       $label = 'warning';
                                                       $font_label = 'arrow-down';  
                                                    }
                                                    elseif($row->trend_name == 'Constant - Red')
                                                    {
                                                       $label = 'danger';
                                                       $font_label = 'exchange';  
                                                    }
                                                    elseif($row->trend_name == 'Constant - Green')
                                                    {
                                                       $label = 'primary';
                                                       $font_label = 'exchange';  
                                                    }
                                                     elseif($row->trend_name == 'Constant - Amber')
                                                    {
                                                       $label = 'warning';
                                                       $font_label = 'exchange';  
                                                    }
                                                    elseif($row->trend_name == 'Downward - Red')  
                                                    {
                                                        $label = 'danger';
                                                        $font_label = 'arrow-down';
                                                    }
                                                    else
                                                    {
                                                        $label = 'primary';
                                                        $font_label = 'arrow-up';
                                                    }
                                                    ?>
                                                    
                                                        <td> 
                                                        <i class="fa fa-<?php echo $font_label;?> fa-lg"></i>
                                                        <span class="label label-<?php echo $label;?>"><?php echo  $row->trend_name;?> </span>  
                                                        </td>
                                                        <td>
                                                        <button class="btn-white btn btn-xs"><i class="fa fa-list"></i><a onClick="viewRegistryFunction(<?php echo $row->id; ?>)" data-toggle="modal" data-target="#viewRegistryModal"> Review </a></button>
                                                        </br> 

                                                        <?php
                                                        $rmu_only = array(4,7);
                                                        if(in_array($this->session->userdata('role'), $rmu_only)) { ?>
                                                        <button class="btn-white btn btn-xs"><i class="fa fa-edit"></i> <a href="<?php echo base_url();?>registry/registry_edit/<?php echo $row->id;?>" > Assess</a></button>
                                                        <?php } ?>

                                                    </td>
                                                </tr>
                                                <?php  }
                                            }else{ ?>
                                                <tr class="gradeX">
                                                    <td colspan="5">Risk Register has no data to assess</td>
                                                </tr>                            
                                                <?php  } ?>                    
                                            </tbody>
                                            <tfoot>
                                            <tr>
                                                <th>Activity</th>
                                                <th>Causes </th>
                                                <th>Events </th>                                                   
                                                <th>Consequences</th>                   
                                                <th>Trend</th>
                                                <th>Action</th>
                                            </tr>
                                            </tfoot>
                                            </table>                                   
                                        </div>
                            </div>
                        </div>
                    <!-- END BODY -->           
                    </div>
                </div>

                <!-- All the Project Risk Category -->
                <div role="tabpanel" id="tab-3" class="tab-pane">
                    <div class="panel-body">
                    <!-- START  BODY -->
                    <div class="row">
                        <div class="col-lg-12">                   
                                    <h4>List of Risk Register (Project Category) </h4>                                                       
                                        <div class="table-responsive">
                                            <table class="table table-striped table-bordered table-hover" id="dataTable3_riskEmerge">
                                            <thead>
                                            <tr>
                                                <th>Activity</th>
                                                <th>Causes </th>
                                                <th>Events </th>                                                   
                                                <th>Consequences</th>                   
                                                <th>Trend</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php 
                                            if($list_project_registry->num_rows() > 0) {
                                                foreach($list_project_registry->result() as $row){
                                            ?>
                                                    <tr class="gradeX">
                                                    <td><?php echo  $row->activity; ?></td>
                                                    <!-- CAUSES -->
                                                    <td>
                                                        <ol>
                                                            <?php
                                                            $list_causes  = $this->registry_model->getRegistry_causes($row->id);
                                                            foreach($list_causes->result() as $cause){?>                                       
                                                                <li><?php echo  $cause->causes; ?></li>
                                                            <?php } ?>
                                                        </ol>
                                                    </td>

                                                    <!-- EVENTS -->
                                                    <td>
                                                        <ol>
                                                            <?php 
                                                            $list_events  = $this->registry_model->getRegistry_events($row->id);
                                                            foreach($list_events->result() as $event){?>                                       
                                                                <li><?php echo  $event->events; ?></li>
                                                            <?php } ?>
                                                        </ol>
                                                    </td>

                                                    <!-- CONSEQUENCES -->
                                                    <td>
                                                        <ol>
                                                            <?php 
                                                            $list_consequences  = $this->registry_model->getRegistry_consequences($row->id);
                                                            foreach($list_consequences->result() as $consequence){?>                                       
                                                                <li><?php echo  $consequence->consequences; ?></li>
                                                            <?php } ?>
                                                        </ol>
                                                    </td>

                                                    <?php
                                                
                                                     
                                                    if($row->trend_name == 'Upward - Amber')
                                                    {
                                                        $label = 'warning';
                                                        $font_label = 'arrow-up';
                                                    }elseif($row->trend_name == 'Downward - Amber')
                                                    {
                                                       $label = 'warning';
                                                       $font_label = 'arrow-down';  
                                                    }
                                                    elseif($row->trend_name == 'Constant - Red')
                                                    {
                                                       $label = 'danger';
                                                       $font_label = 'exchange';  
                                                    }
                                                    elseif($row->trend_name == 'Constant - Green')
                                                    {
                                                       $label = 'primary';
                                                       $font_label = 'exchange';  
                                                    }
                                                     elseif($row->trend_name == 'Constant - Amber')
                                                    {
                                                       $label = 'warning';
                                                       $font_label = 'exchange';  
                                                    }
                                                    elseif($row->trend_name == 'Downward - Red')  
                                                    {
                                                        $label = 'danger';
                                                        $font_label = 'arrow-down';
                                                    }
                                                    else
                                                    {
                                                        $label = 'primary';
                                                        $font_label = 'arrow-up';
                                                    }
                                                    ?>
                                                    
                                                    <td> 
                                                        <i class="fa fa-<?php echo $font_label;?> fa-lg"></i>
                                                        <span class="label label-<?php echo $label;?>"><?php echo  $row->trend_name;?> </span>  
                                                    </td>
                                                    <td>
                                                        <button class="btn-white btn btn-xs"><i class="fa fa-list"></i><a onClick="viewRegistryFunction(<?php echo $row->id; ?>)" data-toggle="modal" data-target="#viewRegistryModal"> Review  </a></button>
                                                        </br> 

                                                        <?php
                                                        $rmu_only = array(4,7);
                                                        if(in_array($this->session->userdata('role'), $rmu_only)) { ?>
                                                        <button class="btn-white btn btn-xs"><i class="fa fa-edit"></i> <a href="<?php echo base_url();?>registry/registry_edit/<?php echo $row->id;?>" > Assess </a></button>
                                                        <?php } ?>
                                                        
                                                    </td>
                                                </tr>
                                                <?php  }
                                            }else{ ?>
                                                <tr class="gradeX">
                                                    <td colspan="5">Risk Register has no data to assess</td>
                                                </tr>                            
                                                <?php  } ?>                    
                                            </tbody>
                                            <tfoot>
                                            <tr>
                                                <th>Activity</th>
                                                <th>Causes </th>
                                                <th>Events </th>                                                   
                                                <th>Consequences</th>                   
                                                <th>Trend</th>
                                                <th>Action</th>
                                            </tr>
                                            </tfoot>
                                            </table>                                   
                                        </div>
                            </div>
                        </div>
                    <!-- END BODY -->  
                    </div>
                </div>
        </div>
      </div>
    </div>
<!-- END -->

















<!-- Start View Risk Registry -->
<div class="modal fade" id="viewRegistryModal" tabindex="-1" role="dialog" aria-labelledby="viewRegistryModal" aria-hidden="true">
       <div class="modal-dialog">    
                 <div class="modal-content">  
                      <div class="modal-header">  
                           <button type="button" class="close" data-dismiss="modal">&times;</button>  
                           <h4 class="modal-title" id="exampleModalLabel">View Risk Registry </h4> 
                      </div>

      <div class="modal-body">
 
                <form method="post">
                    <input type="hidden" name="reporter_id" id="reporter_id" class="form-control" value="<?php echo $this->session->userdata('user_id'); ?>">
                    <div class="form-group">

                        <label><strong> Activity <span class="text-danger">*</span></label> </strong></label>
                        <textarea readonly name="view_activity" id="view_activity" class="form-control">   </textarea>                       

                        <label><strong> Risk Category <span class="text-danger">*</span></label> </strong></label>
                        <input type="text" name="view_risk_category" id="view_risk_category" class="form-control" readonly/> 

                        <label><strong> Risk Owner <span class="text-danger">*</span></label> </strong></label>
                        <input type="text" name="view_risk_owner" id="view_risk_owner" class="form-control" readonly/>

                        <label><strong> Affected Institutional objective(s) <span class="text-danger">*</span></label> </strong></label>
                            <div id="list_objectives">

                            </div>

                        <label><strong> List of Possible Cause(s) </strong></label>
                            <div id="list_causes">

                            </div>   
                            
                        <label><strong> List of Possible Event(s)  </strong></label>
                            <div id="list_events">

                            </div>  
                            
                        <label><strong> List of Possible  Consequence(s)  </strong></label>
                                <div id="list_consequences">

                                </div> 

                        <!-- START INHERIT ANALYSIS -->    
                        <div class="row">
                            <div class="col-sm-4">
                                <label><strong> Impact Score </strong></label>
                                <input type="text" name="view_impact_score" id="view_impact_score" class="form-control" readonly/> 
                            </div> 
                            <div class="col-sm-4">
                                <label><strong> LikeHood Score </strong></label>
                                <input type="text" name="view_like_hood_score" id="view_like_hood_score" class="form-control" readonly/>                            
                            </div> 
                            <div class="col-sm-4">
                                <label><strong> Risk Magnitude <span class="text-danger">*</span></label> </strong></label>
                                <input type="text" name="view_risk_magnitude" id="view_risk_magnitude" class="form-control" readonly/>                        
                            </div> 
                        </div>                                        
                        <!-- END INHERIT ANALYSIS -->
                        
                        <label><strong> List of Existing Control(s)  </strong></label>
                                <div id="list_excontrols">

                                </div>  

                        <!-- START  EFFECTIVE CONTROLS ANALYSIS -->
                        <div class="row">
                            <div class="col-sm-6">
                                <label><strong> Effective of Existing Controls <span class="text-danger">*</span></label> </strong></label>
                                <input type="text" name="view_eff_controls" id="view_eff_controls" class="form-control" readonly/> 
                            </div> 
                            <div class="col-sm-6">
                                <label><strong> Residual Risk Score  <span class="text-danger">*</span></label> </strong></label>
                                <input type="text" name="view_residual_risk_score" id="view_residual_risk_score" class="form-control" readonly/> 
                            </div>  
                        </div>        
                         <!-- END   EFFECTIVE CONTROLS ANALYSIS -->   
                              
                        <label><strong> List of Additional Control(s)  </strong></label>
                                <div id="list_adcontrols">

                                </div>         

                        <label><strong> Remarks <span class="text-danger">*</span></label> </strong></label>
                        <input type="text" name="view_remarks" id="view_remarks" class="form-control" readonly/> 

                        <label><strong> Status <span class="text-danger">*</span></label> </strong></label>
                        <input type="text" name="view_status" id="view_status" class="form-control" readonly/> 

                        <div class="row">
                            <div class="col-sm-4">
                                <label><strong> Trends <span class="text-danger">*</span></label> </strong></label>
                                <input type="text" name="view_trends" id="view_trends" class="form-control" readonly/>  
                            </div> 
                            <div class="col-sm-4">
                                <label><strong> Quarter <span class="text-danger">*</span></label> </strong></label>
                                <input type="text" name="view_quarter" id="view_quarter" class="form-control" readonly/> 
                            </div> 
                            <div class="col-sm-4">
                                <label><strong> Year  <span class="text-danger">*</span></label> </strong></label>
                                <input type="text" name="view_year" id="view_year" class="form-control" readonly/> 
                            </div>  
                        </div> 

                                                                                                            
                                      
                    </div>
                </form>                            
        </div>

        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>        
        </div>
    </div>
  </div>
</div>

<!-- End View Risk Registry -->
</div>

