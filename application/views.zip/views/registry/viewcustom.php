<!-- Start View the Registry Data -->
<script text="javascript">
    function viewRegistryFunction(reg_id){

        viewRegistryObjectives_Function(reg_id);
        viewRegistryCauses_Function(reg_id);
        viewRegistryEvents_Function(reg_id);
        viewRegistryConsequences_Function(reg_id);
        viewRegistryExcontrols_Function(reg_id);
        viewRegistryADControls_Function(reg_id);

        
        $.ajax({
			type:"POST",
            dataType:"json",
			url: "<?php echo base_url();?>registry/view_registry",
			data:{
				reg_id:reg_id, 
				}, 
			success:function(msg){	
				document.getElementById('view_activity').value = msg.activity;
				document.getElementById('view_risk_category').value = msg.objective_category;
                document.getElementById('view_risk_owner').value = msg.name;

                
                document.getElementById('view_remarks').value = msg.rem;
                document.getElementById('view_status').value = msg.sts;
                document.getElementById('view_trends').value = msg.trend_name;

                document.getElementById('view_quarter').value = msg.qua;
                document.getElementById('view_year').value = msg.year;

                var trend =  msg.trends;
                var trend_elem = document.querySelector('#view_trends');

                    //alert(msg.trend_name);

                    //#ffcccb : RED AND #90ee90 : GREEN
                    if(trend == 2){
                        trend_elem.style.backgroundColor  = 'red';
                        trend_elem.style.color  = 'white';
                       
                    }
                    else if(trend == 3){
                        trend_elem.style.backgroundColor  = '#feb204';
                        trend_elem.style.color  = 'white';
                      
                    }
                    else if(trend == 1){
                        trend_elem.style.backgroundColor  = '#008000';
                        trend_elem.style.color  = 'white';
                        
                    }
                    else if(trend == 9){
                        trend_elem.style.backgroundColor  = '#008000';
                        trend_elem.style.color  = 'white';
                       
                    } 
                    else if(trend == 10){
                        trend_elem.style.backgroundColor  = 'red';
                        trend_elem.style.color  = 'white';
                        
                    } 
                    else if(trend == 11){
                        trend_elem.style.backgroundColor  = '#feb204';
                        trend_elem.style.color  = 'white';
                        
                    }else{
                        trend_elem.style.backgroundColor  = '#feb204';  
                        trend_elem.style.color  = 'white';
                                          
                    }


                document.getElementById('view_impact_score').value = msg.impact_scale;
                document.getElementById('view_like_hood_score').value = msg.like_hood_scale;
                // Risk Magnitude 
                var riskMagnitude = (parseInt(msg.impact_scale_id) * parseInt(msg.like_hood_scale_id));
                    document.getElementById('view_risk_magnitude').value = riskMagnitude;
                    var elem = document.querySelector('#view_risk_magnitude');

                    if((1 <= riskMagnitude) && (riskMagnitude <= 7)){
                        elem.style.backgroundColor  = '#008000';
                        elem.style.color  = 'white';
                        document.getElementById("view_risk_magnitude").value = "Normal / Low";
                    }
                    else if((8 <= riskMagnitude) && (riskMagnitude <= 14)){
                        elem.style.backgroundColor  = '#feb204';
                        elem.style.color  = 'white';
                        document.getElementById("view_risk_magnitude").value = "Moderate";
                    }else{
                        elem.style.backgroundColor  = 'red';
                        elem.style.color  = 'white';
                        document.getElementById("view_risk_magnitude").value = "Key";
                    }
              
				document.getElementById('view_eff_controls').value = msg.controls_effectiveness_scale;
                // Residual Risk Score
                var residualRiskScore = (parseInt(riskMagnitude) / parseInt(msg.controls_effectiveness_scale_id));
                    document.getElementById('view_residual_risk_score').value = residualRiskScore;
                    var New_elem = document.querySelector('#view_residual_risk_score');

                    if((1 <= residualRiskScore) && (residualRiskScore <= 7)){
                        New_elem.style.backgroundColor  = '#008000';
                        New_elem.style.color  = 'white';
                        document.getElementById("view_residual_risk_score").value = "Low";
                    }
                    else if((8 <= residualRiskScore) && (residualRiskScore <= 14)){
                        New_elem.style.backgroundColor  = '#feb204';
                        New_elem.style.color  = 'white';
                        document.getElementById("view_residual_risk_score").value = "Medium";
                    }else{
                        New_elem.style.backgroundColor  = 'red';
                        New_elem.style.color  = 'white';
                        document.getElementById("view_residual_risk_score").value = "High";
                    }
                
			}
		});
	}
</script>


<script text="javascript">
    // Start Get All Objectives  
    function viewRegistryObjectives_Function(reg_id){
        $.ajax({
			type:"POST",
            dataType:"json",
			url: "<?php echo base_url();?>registry/registry_view_objectives",
			data:{
				reg_id:reg_id, 
				}, 
			success:function(msg){
                var objectives = '';
                    objectives += '<ol>';
                    // Start loop here
                    for(var i = 0; i < msg.length; i++) {                       
                        objectives += '<li>'+ msg[i].name +'</li>';
                    }
                    // End Loop here
                    objectives += '</ol>';
                $('#list_objectives').html(objectives);																	          
			}
		});
	}
    // End Get All Objectives  

    // Start Get All Registry Causes
    function viewRegistryCauses_Function(reg_id){
        $.ajax({
			type:"POST",
            dataType:"json",
			url: "<?php echo base_url();?>registry/registry_view_causes",
			data:{
				reg_id:reg_id, 
				}, 
			success:function(msg){
                var cau = '';
                    cau += '<ol>';
                    // Start loop here 
                    for(var i = 0; i < msg.length; i++) {                       
                        cau += '<li>'+ msg[i].causes +'</li>';
                    }               
                    // End Loop here
                    cau += '</ol>';
                $('#list_causes').html(cau);
			}
		});
	}
    // End Get All Registry Causes

    // Start Get All Registry Events
    function viewRegistryEvents_Function(reg_id){
        $.ajax({
			type:"POST",
            dataType:"json",
			url: "<?php echo base_url();?>registry/registry_view_events",
			data:{
				reg_id:reg_id, 
				}, 
			success:function(msg){
                var eve = '';
                    eve += '<ol>';
                    // Start loop here 
                    for(var i = 0; i < msg.length; i++) {                       
                        eve += '<li>'+ msg[i].events +'</li>';
                    }               
                    // End Loop here
                    eve += '</ol>';
                $('#list_events').html(eve);
			}
		});
	}
    // End Get All Registry Events

    // Start Get All Registry Consequences
     function viewRegistryConsequences_Function(reg_id){
        $.ajax({
			type:"POST",
            dataType:"json",
			url: "<?php echo base_url();?>registry/registry_view_consequences",
			data:{
				reg_id:reg_id, 
				}, 
			success:function(msg){
                var cons = '';
                    cons += '<ol>';
                    // Start loop here 
                    for(var i = 0; i < msg.length; i++) {                       
                        cons += '<li>'+ msg[i].consequences +'</li>';
                    }               
                    // End Loop here
                    cons += '</ol>';
                $('#list_consequences').html(cons);
			}
		});
	}
    // End Get All Registry Consequences

    // Start Get All Registry Existing Controls
    function viewRegistryExcontrols_Function(reg_id){
        $.ajax({
			type:"POST",
            dataType:"json",
			url: "<?php echo base_url();?>registry/registry_view_excontrols",
			data:{
				reg_id:reg_id, 
				}, 
			success:function(msg){
                var exco = '';
                    exco += '<ol>';
                    // Start loop here 
                    for(var i = 0; i < msg.length; i++) {                       
                        exco += '<li>'+ msg[i].excontrols +'</li>';
                    }               
                    // End Loop here
                    exco += '</ol>';
                $('#list_excontrols').html(exco);
			}
		});
	}
    // End Get All Registry Consequences

    // Start Get All Registry Additional Controls
    function viewRegistryADControls_Function(reg_id){
        $.ajax({
			type:"POST",
            dataType:"json",
			url: "<?php echo base_url();?>registry/registry_view_adcontrols",
			data:{
				reg_id:reg_id, 
				}, 
			success:function(msg){
                var adco = '';
                    adco += '<ol>';
                    // Start loop here 
                    for(var i = 0; i < msg.length; i++) {                       
                        adco += '<li>'+ msg[i].adcontrols +'</li>';
                    }               
                    // End Loop here
                    adco += '</ol>';
                $('#list_adcontrols').html(adco);
			}
		});
	}

  
    // End Get All Registry Consequences
</script>
<!-- End View the Registry Data -->

<!-- Start Javascript here --->
<script text="javascript">

    $(document).ready(function () {

        $('#dataTable_riskEmerge').DataTable({
            "ordering": false
        });

        $('#dataTable2_riskEmerge').DataTable({
            "ordering": false
        });

        $('#dataTable3_riskEmerge').DataTable({
            "ordering": false
        });

    });

</script>
<!-- End Javascript here --->

<!-- CLOSE PAGE -->
</div>
</div>
</body>
</html>