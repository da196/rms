<!-- Start Javascript here --->
<script text="javascript">

    $(document).ready(function () {

        $('#dataTable_riskEmerge').DataTable();

    });

</script>


<!-- End Javascript here --->

<!-- CLOSE PAGE -->
</div>
</div>
</body>
</html>