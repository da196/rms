    
<!-- Foot-Note -->
<div class="footer">
     <div class="col-md-12 text-center">
         &copy;  Tanzania Communications Regulatory Authority <script>document.write(new Date().getFullYear())</script>. All Rights Reserved
     </div>
 </div>
