<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>TCRA | ERMS</title>

    <link href="<?=base_url()?>public/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=base_url()?>public/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">

    
    <link href="<?=base_url()?>public/font-awesome/css/font-awesome.css" rel="stylesheet">
    <!-- <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.css" rel="stylesheet"> -->

    <!-- Sweet Alert -->
    <link href="<?=base_url()?>public/css/plugins/sweetalert/sweetalert.css" rel="stylesheet">

    <!-- Datatable -->
    <link href="<?=base_url()?>public/css/plugins/dataTables/datatables.min.css" rel="stylesheet">
   <!--  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css"> -->

   

    <!-- Toastr style -->
    <link href="<?=base_url()?>public/css/plugins/toastr/toastr.min.css" rel="stylesheet">

    <!-- Gritter -->
    <link href="<?=base_url()?>public/js/plugins/gritter/jquery.gritter.css" rel="stylesheet">

    <link href="<?=base_url()?>public/css/animate.css" rel="stylesheet">
    <link href="<?=base_url()?>public/css/style.css" rel="stylesheet">

    <!-- FOR SEARCHABLE SELECT OPTION TAGS -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />

    <!-- ERMS STYLES -->
    <link href="<?=base_url()?>public/css/erms_style.css" rel="stylesheet">


    


</head>

<body>
<div id="wrapper"> 

    <!-- include sibebar -->
    <?php
          $this->load->view('include/sidebar');
    ?>

    <!-- include topbar -->
    <?php
          $this->load->view('include/topbar');
    ?>
      