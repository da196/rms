 <!-- Mainly scripts -->
 <script src="<?=base_url()?>public/js/jquery-2.1.1.js"></script>
 <script src="<?=base_url()?>public/js/popper.min.js"></script>
 <script src="<?=base_url()?>public/js/bootstrap.min.js"></script>
 <script src="<?=base_url()?>public/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>

  <!-- FOR SEARCHABLE SELECT OPTION TAGS -->
  <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
 
 
 <script src="<?=base_url()?>public/js/plugins/metisMenu/jquery.metisMenu.js"></script>
 <script src="<?=base_url()?>public/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

 <!-- Datatable -->
 <script src="<?=base_url()?>public/js/plugins/jeditable/jquery.jeditable.js"></script>

 <script src="<?=base_url()?>public/js/plugins/dataTables/datatables.min.js"></script>
 <!--  <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>    -->  

 <!-- Flot -->
 <script src="<?=base_url()?>public/js/plugins/flot/jquery.flot.js"></script>
 <script src="<?=base_url()?>public/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
 <script src="<?=base_url()?>public/js/plugins/flot/jquery.flot.spline.js"></script>
 <script src="<?=base_url()?>public/js/plugins/flot/jquery.flot.resize.js"></script>
 <script src="<?=base_url()?>public/js/plugins/flot/jquery.flot.pie.js"></script>

 <!-- Peity -->
 <script src="<?=base_url()?>public/js/plugins/peity/jquery.peity.min.js"></script>
 <script src="<?=base_url()?>public/js/demo/peity-demo.js"></script>

 <!-- Custom and plugin javascript -->
 <script src="<?=base_url()?>public/js/inspinia.js"></script>
 <script src="<?=base_url()?>public/js/plugins/pace/pace.min.js"></script>

 <!-- Sweet alert -->
 <script src="<?=base_url()?>public/js/plugins/sweetalert/sweetalert.min.js"></script>





 <!-- jQuery UI -->
 <script src="<?=base_url()?>public/js/plugins/jquery-ui/jquery-ui.min.js"></script>

 <!-- GITTER -->
 <script src="<?=base_url()?>public/js/plugins/gritter/jquery.gritter.min.js"></script>

 <!-- Sparkline -->
 <script src="<?=base_url()?>public/js/plugins/sparkline/jquery.sparkline.min.js"></script>

 <!-- Sparkline demo data  -->
 <script src="<?=base_url()?>public/js/demo/sparkline-demo.js"></script>

 <!-- ChartJS-->
 <script src="<?=base_url()?>public/js/plugins/chartJs/Chart.min.js"></script>


 <!-- Toastr -->
 <script src="<?=base_url()?>public/js/plugins/toastr/toastr.min.js"></script>

 <!-- ERMS Scripts -->
 <script src="<?=base_url()?>public/js/erms.js"></script>